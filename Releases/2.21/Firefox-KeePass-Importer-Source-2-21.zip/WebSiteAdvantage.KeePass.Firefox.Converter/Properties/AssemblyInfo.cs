using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Web Site Advantage KeePass Firefox Converter")]
[assembly: AssemblyDescription("Converts FireFox Passwords into KeePass XML")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Anthony James McCreath")]
[assembly: AssemblyProduct("KeePass Utility")]
[assembly: AssemblyCopyright("Copyright © 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("10683f55-9889-4acf-8e0a-e60c4f19f6c9")]
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.21.0.21106")]
[assembly: AssemblyFileVersion("2.21.0.0")]

