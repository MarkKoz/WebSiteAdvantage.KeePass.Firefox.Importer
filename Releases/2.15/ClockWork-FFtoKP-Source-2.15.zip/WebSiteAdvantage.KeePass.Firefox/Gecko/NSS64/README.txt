The following files will probably needed in their 64bit version from the firefox installation:

freebl3.chk
freebl3.dll
js3250.dll
mozcrt19.dll
nspr4.dll
nss3.dll
nssckbi.dll
nssdbm3.dll
nssutil3.dll
plc4.dll
plds4.dll
smime3.dll
softokn3.chk
softokn3.dll
sqlite3.dll
ssl3.dll
xpcom.dll