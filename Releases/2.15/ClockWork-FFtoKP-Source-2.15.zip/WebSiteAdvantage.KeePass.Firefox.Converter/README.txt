References
   KeePass (http://keepass.info/help/v2_dev/plg_index.html)
   FireFox - Internet Browser (http://www.mozilla.com)
   FireFox - Password Exporter Extension by Justin Scott (https://addons.mozilla.org/en-US/firefox/addon/2848)
   System.Data.SQLite - used to access Firefox's database (http://sqlite.phxsoftware.com/)
 
Support, Instructions & Help
	http://mccreath.org.uk/geeky/12-clockwork-firefox-to-keepass-converter

